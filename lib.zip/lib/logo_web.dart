import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import './logo_web_home.dart';
import 'package:adobe_xd/page_link.dart';

class logo_Web extends StatelessWidget {
  logo_Web({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffe5e5e5),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(size: 308.0, middle: 0.5),
            Pin(size: 177.0, middle: 0.247),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Montserrat',
                  fontSize: 100,
                  color: const Color(0xff293241),
                ),
                children: [
                  TextSpan(
                    text: 'LOGO\n',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  TextSpan(
                    text: 'ADMIN AREA',
                    style: TextStyle(
                      fontSize: 45,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              textHeightBehavior:
                  TextHeightBehavior(applyHeightToFirstAscent: false),
              textAlign: TextAlign.center,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 418.0, middle: 0.5),
            Pin(size: 68.0, middle: 0.4318),
            child:
                // Adobe XD layer: 'Mail' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Down' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(34.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 80.0, start: 30.0),
                  Pin(size: 35.0, middle: 0.5152),
                  child: Text(
                    'Mail...',
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 29,
                      color: const Color(0xff293241),
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w300,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 418.0, middle: 0.5),
            Pin(size: 68.0, middle: 0.5425),
            child:
                // Adobe XD layer: 'Password' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Down' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(34.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 158.0, start: 30.0),
                  Pin(size: 35.0, middle: 0.5152),
                  child: Text(
                    'Password...',
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 29,
                      color: const Color(0xff293241),
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w300,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 418.0, middle: 0.5),
            Pin(size: 68.0, middle: 0.6522),
            child:
                // Adobe XD layer: 'Code' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Down' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(34.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 92.0, start: 30.0),
                  Pin(size: 35.0, middle: 0.5152),
                  child: Text(
                    'Code...',
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 29,
                      color: const Color(0xff293241),
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w300,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 216.0, middle: 0.5),
            Pin(size: 62.0, middle: 0.7809),
            child:
                // Adobe XD layer: 'LOGIN-BUTTON' (group)
                PageLink(
              links: [
                PageLinkInfo(
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => logo_WebHome(),
                ),
              ],
              child: Stack(
                children: <Widget>[
                  Pinned.fromPins(
                    Pin(start: 0.0, end: 0.0),
                    Pin(start: 0.0, end: 0.0),
                    child:
                        // Adobe XD layer: 'Button' (shape)
                        Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(31.0),
                        color: const Color(0xffee6c4d),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0x29000000),
                            offset: Offset(0, 3),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Pinned.fromPins(
                    Pin(size: 136.0, middle: 0.5),
                    Pin(start: 7.0, end: 6.0),
                    child: Text(
                      'LOGIN',
                      style: TextStyle(
                        fontFamily: 'Montserrat',
                        fontSize: 40,
                        color: const Color(0xffffffff),
                        fontWeight: FontWeight.w900,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
