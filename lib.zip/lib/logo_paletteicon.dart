import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:flutter_svg/flutter_svg.dart';

class logo_Paletteicon extends StatelessWidget {
  logo_Paletteicon({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffe5e5e5),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 16.0, end: 15.0),
            Pin(start: 36.0, end: 36.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(17.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 26.7, start: 56.4),
            Pin(size: 26.7, middle: 0.4847),
            child:
                // Adobe XD layer: 'Comment' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: SvgPicture.string(
                    _svg_s6gd6,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 15.8, middle: 0.4465),
                  Pin(size: 1.0, middle: 0.4514),
                  child: SvgPicture.string(
                    _svg_xlbbe,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 11.2, middle: 0.3124),
                  Pin(size: 1.0, middle: 0.6691),
                  child: SvgPicture.string(
                    _svg_z3c8p9,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 32.1, start: 53.3),
            Pin(size: 28.4, middle: 0.4344),
            child:
                // Adobe XD layer: 'Heart' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: SvgPicture.string(
                    _svg_snjl6m,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 32.3, start: 53.1),
            Pin(size: 32.3, middle: 0.3805),
            child:
                // Adobe XD layer: 'Search' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 25.1, start: 0.0),
                  Pin(size: 25.1, start: 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                      border: Border.all(
                          width: 2.0, color: const Color(0xff000000)),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 10.9, end: 0.0),
                  Pin(size: 10.9, end: 0.0),
                  child: SvgPicture.string(
                    _svg_wvuuo,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 32.6, start: 53.4),
            Pin(size: 32.6, middle: 0.3243),
            child:
                // Adobe XD layer: 'Edit' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Artboard' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'edit' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 3.3),
                              Pin(start: 3.3, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Shape' (shape)
                                  SvgPicture.string(
                                _svg_expio,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 22.8, end: 0.0),
                              Pin(size: 22.8, start: 0.0),
                              child:
                                  // Adobe XD layer: 'Shape' (shape)
                                  SvgPicture.string(
                                _svg_quhnxf,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 38.0, start: 50.4),
            Pin(size: 25.0, middle: 0.2744),
            child:
                // Adobe XD layer: 'Menu' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 1.0, start: 0.0),
                  child: SvgPicture.string(
                    _svg_p0drr,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 1.0, middle: 0.521),
                  child: SvgPicture.string(
                    _svg_jaobsh,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 1.0, end: -1.0),
                  child: SvgPicture.string(
                    _svg_y8kt5g,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 31.4, start: 53.9),
            Pin(size: 31.4, middle: 0.2147),
            child:
                // Adobe XD layer: 'Plus' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 1.0, middle: 0.5164),
                  Pin(start: 0.0, end: 0.0),
                  child: SvgPicture.string(
                    _svg_lb5ku4,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 1.0, middle: 0.5164),
                  child: SvgPicture.string(
                    _svg_z4f6o,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 28.3, start: 54.8),
            Pin(size: 32.0, start: 132.6),
            child:
                // Adobe XD layer: 'User' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Artboard' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'user' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 10.6, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Shape' (shape)
                                  SvgPicture.string(
                                _svg_lmvx7h,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 14.1, middle: 0.5),
                              Pin(size: 14.1, start: 0.0),
                              child:
                                  // Adobe XD layer: 'Oval' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(
                                      Radius.elliptical(9999.0, 9999.0)),
                                  border: Border.all(
                                      width: 2.0,
                                      color: const Color(0xff000000)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 30.5, start: 54.2),
            Pin(size: 31.4, start: 80.2),
            child:
                // Adobe XD layer: 'Home' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child: SvgPicture.string(
                    _svg_pvbq47,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.5632),
            Pin(size: 66.0, start: 73.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xff293241),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.7874),
            Pin(size: 66.0, start: 73.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffee6c4d),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.5632),
            Pin(size: 66.0, middle: 0.1819),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xff3d5a80),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.7874),
            Pin(size: 66.0, middle: 0.1819),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.5632),
            Pin(size: 66.0, middle: 0.2759),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xff98c1d9),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.7874),
            Pin(size: 66.0, middle: 0.2759),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.5632),
            Pin(size: 66.0, middle: 0.3699),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffe0fbfc),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.7874),
            Pin(size: 66.0, middle: 0.3699),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.5632),
            Pin(size: 66.0, middle: 0.4639),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffe5e5e5),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 66.0, middle: 0.7874),
            Pin(size: 66.0, middle: 0.4639),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                gradient: LinearGradient(
                  begin: Alignment(-1.0, -1.0),
                  end: Alignment(1.15, 1.0),
                  colors: [const Color(0xff3d5a80), const Color(0xffee6c4d)],
                  stops: [0.0, 1.0],
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x40000000),
                    offset: Offset(0, 6),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 80.0, end: 80.0),
            Pin(size: 24.0, start: 24.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.0),
                color: const Color(0xffe5e5e5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_s6gd6 =
    '<svg viewBox="0.0 0.0 26.7 26.7" ><path transform="translate(-40.0, -31.99)" d="M 53.34298324584961 58.67813110351562 L 41.11191940307617 58.67813110351562 C 40.49785995483398 58.67813110351562 40.00004959106445 58.18036651611328 40.00000381469727 57.56631088256836 L 40.00000381469727 45.33514785766602 C 40.00000381469727 37.96604537963867 45.97384262084961 31.99219512939453 53.34295272827148 31.99219512939453 L 53.34298324584961 31.99219512939453 C 60.71210861206055 31.99219512939453 66.68595886230469 37.96605682373047 66.68595886230469 45.33518218994141 L 66.68595886230469 45.335205078125 C 66.68595886230469 52.70428848266602 60.71211624145508 58.67813110351562 53.34300231933594 58.67813110351562 Z" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_xlbbe =
    '<svg viewBox="4.8 11.6 15.8 1.0" ><path transform="translate(4.84, 11.59)" d="M 0 0 L 15.83887100219727 0" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_z3c8p9 =
    '<svg viewBox="4.8 17.2 11.2 1.0" ><path transform="translate(4.84, 17.19)" d="M 0 0 L 11.18037986755371 0" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_snjl6m =
    '<svg viewBox="0.0 0.0 32.1 28.4" ><path transform="translate(-11.66, -13.99)" d="M 27.69524002075195 42.37678146362305 L 15.35012817382812 30.03166961669922 C 5.377864837646484 20.05940628051758 17.72297668457031 7.69064474105835 27.69524002075195 17.67867469787598 C 37.65962219238281 7.69064474105835 50.00473022460938 20.06728935241699 40.04823303222656 30.03166961669922 L 27.69524002075195 42.37678146362305 Z" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="butt" stroke-linejoin="round" /></svg>';
const String _svg_wvuuo =
    '<svg viewBox="21.4 21.4 10.9 10.9" ><path transform="translate(21.38, 21.38)" d="M 0 0 L 10.89804172515869 10.89804172515869" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_expio =
    '<svg viewBox="0.0 3.3 29.4 29.4" ><path transform="translate(0.0, 1.26)" d="M 29.36590576171875 19.39114379882812 L 29.36590576171875 28.10302734375 C 29.36590576171875 29.90506362915039 27.90506172180176 31.36590385437012 26.10302925109863 31.36590385437012 L 3.262878656387329 31.36590385437012 C 1.460840225219727 31.36590385437012 0 29.90506362915039 0 28.10302734375 L 0 5.26287841796875 C 0 3.460839986801147 1.460840940475464 1.999999284744263 3.262878894805908 1.999999523162842 L 11.97476291656494 1.999999523162842" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_quhnxf =
    '<svg viewBox="9.8 0.0 22.8 22.8" ><path transform="translate(3.79, 0.0)" d="M 22.31439208984375 0 L 28.84015083312988 6.525757312774658 L 12.52575778961182 22.84014892578125 L 6 22.84014892578125 L 6 16.31439208984375 L 22.31439208984375 0 Z" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_p0drr =
    '<svg viewBox="0.0 0.0 38.0 1.0" ><path transform="translate(0.0, 0.0)" d="M 0 0 L 38.04061126708984 0" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_jaobsh =
    '<svg viewBox="0.0 12.5 38.0 1.0" ><path transform="translate(0.0, 12.49)" d="M 0 0 L 38.04061126708984 0" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_y8kt5g =
    '<svg viewBox="0.0 25.0 38.0 1.0" ><path transform="translate(0.0, 24.97)" d="M 0 0 L 38.04061126708984 0" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_lb5ku4 =
    '<svg viewBox="15.7 0.0 1.0 31.4" ><path transform="translate(15.72, 0.0)" d="M 0 0 L 0 31.43665885925293" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_z4f6o =
    '<svg viewBox="0.0 15.7 31.4 1.0" ><path transform="matrix(0.0, 1.0, -1.0, 0.0, 31.44, 15.72)" d="M 0 0 L 0 31.43665885925293" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_lmvx7h =
    '<svg viewBox="0.0 21.4 28.3 10.6" ><path transform="translate(0.0, 9.41)" d="M 28.25937652587891 22.59726715087891 L 28.25937652587891 19.06484603881836 C 28.25937652587891 15.1630392074585 25.09634017944336 12 21.19453430175781 12 L 7.064844131469727 12 C 3.16303825378418 12 -8.421950496995123e-07 15.1630392074585 0 19.06484603881836 L 0 22.59726715087891" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_pvbq47 =
    '<svg viewBox="0.0 0.0 30.5 31.4" ><path transform="translate(-40.0, -34.8)" d="M 59.41110992431641 64.82182312011719 L 59.41110992431641 56.50212097167969 C 59.41110992431641 55.73632431030273 58.79031372070312 55.11552810668945 58.02452087402344 55.11552810668945 L 52.47816848754883 55.11552810668945 C 51.71237945556641 55.11552810668945 51.09158325195312 55.73632431030273 51.09158325195312 56.50212097167969 L 51.09158325195312 64.82182312011719 C 51.09158325195312 65.58754730224609 50.47089385986328 66.20831298828125 49.70516967773438 66.20840454101562 L 41.38666534423828 66.20950317382812 C 40.62063217163086 66.20950317382812 39.99980926513672 65.58860015869141 39.99990463256836 64.82273864746094 L 39.99990463256836 48.79735565185547 C 39.99990463256836 48.40673065185547 40.16466903686523 48.03422546386719 40.45368194580078 47.77144241333008 L 54.31861114501953 35.164794921875 C 54.84748077392578 34.68391418457031 55.65525054931641 34.68388748168945 56.18415832519531 35.16473007202148 L 70.05099487304688 47.77143096923828 C 70.34004211425781 48.03420639038086 70.50483703613281 48.40671920776367 70.50485229492188 48.79736709594727 L 70.50485229492188 64.82286071777344 C 70.50485229492188 65.58871459960938 69.88394165039062 66.20954132080078 69.11808776855469 66.20944213867188 L 60.79753494262695 66.20835113525391 C 60.03199005126953 66.20835113525391 59.41122436523438 65.58768463134766 59.41110992431641 64.82197570800781 Z" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
