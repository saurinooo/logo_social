import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import './logo_web.dart';
import 'package:adobe_xd/page_link.dart';
import './logo_web_home1.dart';
import 'package:flutter_svg/flutter_svg.dart';

class logo_WebHome extends StatelessWidget {
  logo_WebHome({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffe5e5e5),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(size: 254.0, start: 21.0),
            Pin(size: 379.0, start: 102.0),
            child:
                // Adobe XD layer: 'Menu' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 27.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'NavBar' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(16.0),
                        bottomLeft: Radius.circular(16.0),
                      ),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 13.0, end: 14.0),
                  Pin(size: 13.0, start: 0.0),
                  child:
                      // Adobe XD layer: 'Null' (shape)
                      Container(
                    decoration: BoxDecoration(
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 27.0, end: 0.0),
                  Pin(size: 27.0, start: 0.0),
                  child:
                      // Adobe XD layer: 'Null' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                      color: const Color(0xffe5e5e5),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 21.0, end: 21.0),
            Pin(size: 81.0, start: 21.0),
            child:
                // Adobe XD layer: 'Menu-Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Menu' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20.0),
                        topRight: Radius.circular(20.0),
                        bottomRight: Radius.circular(20.0),
                      ),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 117.0, start: 29.0),
                  Pin(size: 47.0, middle: 0.5),
                  child: Text(
                    'LOGO',
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 38,
                      color: const Color(0xff293241),
                      fontWeight: FontWeight.w900,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 32.3, end: 41.7),
                  Pin(size: 32.3, middle: 0.5),
                  child:
                      // Adobe XD layer: 'Search' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 25.1, start: 0.0),
                        Pin(size: 25.1, start: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(
                                Radius.elliptical(9999.0, 9999.0)),
                            border: Border.all(
                                width: 3.0, color: const Color(0xff293241)),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 10.9, end: 0.0),
                        Pin(size: 10.9, end: 0.0),
                        child: SvgPicture.string(
                          _svg_id32xa,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 275.0, end: 91.0),
                  Pin(size: 34.0, middle: 0.5106),
                  child:
                      // Adobe XD layer: 'Search' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.0),
                      color: const Color(0xffe5e5e5),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 127.0, end: 226.0),
                  Pin(size: 24.0, middle: 0.5088),
                  child: Text(
                    'User search...',
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 20,
                      color: const Color(0xff293241),
                      fontWeight: FontWeight.w300,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 199.0, start: 35.0),
            Pin(size: 321.0, start: 143.0),
            child:
                // Adobe XD layer: 'Menu-SxBar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 37.0),
                  child:
                      // Adobe XD layer: 'NavBar' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(9.0),
                      color: const Color(0xffe5e5e5),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 5.0, end: 4.0),
                  Pin(size: 84.0, end: 43.0),
                  child:
                      // Adobe XD layer: 'User' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(start: 0.0, end: 0.0),
                        child:
                            // Adobe XD layer: 'Account-Bg' (shape)
                            Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6.0),
                            color: const Color(0xffffffff),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 46.0, middle: 0.3472),
                        Pin(size: 16.0, start: 8.0),
                        child: Text(
                          'ADMIN',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 13,
                            color: const Color(0xff293241),
                            fontWeight: FontWeight.w300,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 120.0, end: 20.0),
                        Pin(size: 13.0, middle: 0.3944),
                        child: Text(
                          'admin.logo@gmail.com',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 10,
                            color: const Color(0xff293241),
                            fontWeight: FontWeight.w300,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 39.0, start: 5.0),
                        Pin(size: 39.0, start: 5.0),
                        child:
                            // Adobe XD layer: 'Image' (shape)
                            Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.0),
                            image: DecorationImage(
                              image: const AssetImage(''),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 62.0, start: 20.0),
                        Pin(size: 18.0, end: 5.0),
                        child:
                            // Adobe XD layer: 'ExitButton' (group)
                            PageLink(
                          links: [
                            PageLinkInfo(
                              ease: Curves.easeOut,
                              duration: 0.3,
                              pageBuilder: () => logo_Web(),
                            ),
                          ],
                          child: Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(start: 0.0, end: 0.0),
                                Pin(start: 0.0, end: 0.0),
                                child:
                                    // Adobe XD layer: 'ExitBg' (shape)
                                    Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(4.0),
                                    color: const Color(0xffff4949),
                                  ),
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 12.3, start: 9.0),
                                Pin(size: 12.3, middle: 0.5),
                                child:
                                    // Adobe XD layer: 'Exit' (group)
                                    Stack(
                                  children: <Widget>[
                                    Pinned.fromPins(
                                      Pin(start: 0.0, end: 0.0),
                                      Pin(start: 0.0, end: 0.0),
                                      child: SvgPicture.string(
                                        _svg_ls6kho,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                    Pinned.fromPins(
                                      Pin(size: 8.6, start: 0.0),
                                      Pin(start: 2.9, end: 2.9),
                                      child: SvgPicture.string(
                                        _svg_r94of5,
                                        allowDrawingOutsideViewBox: true,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 25.0, middle: 0.7445),
                                Pin(start: 2.0, end: 2.0),
                                child: Text(
                                  'EXIT',
                                  style: TextStyle(
                                    fontFamily: 'Montserrat',
                                    fontSize: 11,
                                    color: const Color(0xffffffff),
                                    fontStyle: FontStyle.italic,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 72.0, end: 20.0),
                        Pin(size: 18.0, end: 5.0),
                        child:
                            // Adobe XD layer: 'SettingsButton' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'ExitBg' (shape)
                                  Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.0),
                                  color: const Color(0xff293241),
                                ),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 48.0, end: 4.4),
                              Pin(start: 2.0, end: 2.0),
                              child: Text(
                                'SETTING',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 11,
                                  color: const Color(0xffffffff),
                                  fontStyle: FontStyle.italic,
                                  fontWeight: FontWeight.w600,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 12.0, start: 4.0),
                              Pin(start: 4.0, end: 4.0),
                              child: SvgPicture.string(
                                _svg_o73wkp,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 5.0, end: 4.0),
                  Pin(size: 116.0, start: 5.0),
                  child:
                      // Adobe XD layer: 'Bg' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 120.0, middle: 0.4684),
                  Pin(size: 20.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'AdminArea' (text)
                      Text(
                    'ADMIN AREA',
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 17,
                      color: const Color(0xff293241),
                      fontWeight: FontWeight.w900,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 136.0, middle: 0.5159),
                  Pin(size: 99.0, start: 13.0),
                  child:
                      // Adobe XD layer: 'Section' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 12.5, end: 11.5),
                        Pin(size: 24.0, start: 0.0),
                        child:
                            // Adobe XD layer: 'Select' (shape)
                            Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            color: const Color(0xffee6c4d),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xffee6c4d),
                                offset: Offset(0, 3),
                                blurRadius: 6,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 42.0, middle: 0.5053),
                        Pin(size: 19.0, start: 2.0),
                        child: Text(
                          'USER',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 15,
                            color: const Color(0xffffffff),
                            fontWeight: FontWeight.w300,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 64.0, middle: 0.5069),
                        Pin(size: 19.0, middle: 0.5),
                        child: Text(
                          'REPORT',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 15,
                            color: const Color(0xff293241),
                            fontWeight: FontWeight.w300,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 54.0, middle: 0.5061),
                        Pin(size: 19.0, end: 0.0),
                        child: Text(
                          'OTHER',
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontSize: 15,
                            color: const Color(0xff293241),
                            fontWeight: FontWeight.w300,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 1.0, middle: 0.3112),
                        child: SvgPicture.string(
                          _svg_mff9v5,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 1.0, middle: 0.7194),
                        child: SvgPicture.string(
                          _svg_f5ver5,
                          allowDrawingOutsideViewBox: true,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 257.0, end: 65.0),
            Pin(start: 111.0, end: 64.0),
            child:
                // Adobe XD layer: 'Info-Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(start: 0.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Bg' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(9.0),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 36.5, end: 35.5),
                  Pin(size: 1.0, start: 75.5),
                  child:
                      // Adobe XD layer: 'Line' (shape)
                      SvgPicture.string(
                    _svg_lsenq1,
                    allowDrawingOutsideViewBox: true,
                    fit: BoxFit.fill,
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 26.0, end: 26.0),
                  Pin(start: 27.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Txt-Sepair' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 33.0, end: 72.0),
                        Pin(size: 41.0, start: 0.0),
                        child:
                            // Adobe XD layer: 'UserTable' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(size: 112.0, start: 211.7),
                              Pin(size: 25.0, end: 6.0),
                              child: Text(
                                'NickName',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 21,
                                  color: const Color(0xff293241),
                                  fontStyle: FontStyle.italic,
                                  fontWeight: FontWeight.w300,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 46.0, middle: 0.3065),
                              Pin(size: 25.0, end: 6.0),
                              child: Text(
                                'Mail',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 21,
                                  color: const Color(0xff293241),
                                  fontStyle: FontStyle.italic,
                                  fontWeight: FontWeight.w300,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 106.0, middle: 0.4315),
                              Pin(size: 25.0, end: 6.0),
                              child: Text(
                                'Full name',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 21,
                                  color: const Color(0xff293241),
                                  fontStyle: FontStyle.italic,
                                  fontWeight: FontWeight.w300,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 59.0, middle: 0.5561),
                              Pin(size: 25.0, end: 6.0),
                              child: Text(
                                'Verify',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 21,
                                  color: const Color(0xff293241),
                                  fontStyle: FontStyle.italic,
                                  fontWeight: FontWeight.w300,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 54.0, middle: 0.6841),
                              Pin(size: 25.0, end: 6.0),
                              child: Text(
                                'Code',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 21,
                                  color: const Color(0xff293241),
                                  fontStyle: FontStyle.italic,
                                  fontWeight: FontWeight.w300,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 42.0, end: 0.0),
                              Pin(size: 25.0, end: 6.0),
                              child: Text(
                                'Edit',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 21,
                                  color: const Color(0xff293241),
                                  fontStyle: FontStyle.italic,
                                  fontWeight: FontWeight.w300,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 122.0, start: 0.0),
                              Pin(size: 25.0, end: 6.0),
                              child: Text(
                                'User image',
                                style: TextStyle(
                                  fontFamily: 'Montserrat',
                                  fontSize: 21,
                                  color: const Color(0xff293241),
                                  fontStyle: FontStyle.italic,
                                  fontWeight: FontWeight.w300,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.0, start: 162.0),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Sepair' (shape)
                                  SvgPicture.string(
                                _svg_i2lg39,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.0, middle: 0.2545),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Sepair' (shape)
                                  SvgPicture.string(
                                _svg_wwi3s,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.0, middle: 0.372),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Sepair' (shape)
                                  SvgPicture.string(
                                _svg_h40j9,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.0, middle: 0.5039),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Sepair' (shape)
                                  SvgPicture.string(
                                _svg_eg3vye,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(size: 1.0, middle: 0.6043),
                              Pin(start: 0.0, end: 0.0),
                              child:
                                  // Adobe XD layer: 'Sepair' (shape)
                                  SvgPicture.string(
                                _svg_vtr839,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 1546.0, middle: 0.5),
                        Pin(start: 48.5, end: 0.0),
                        child: Scrollbar(
                          child: SingleChildScrollView(
                            child: SizedBox(
                              width: 1546.0,
                              height: 1208.0,
                              child: Stack(
                                children: <Widget>[
                                  Pinned.fromPins(
                                    Pin(start: 0.0, end: 0.0),
                                    Pin(size: 65.0, start: 16.5),
                                    child:
                                        // Adobe XD layer: 'Hover' (shape)
                                        Container(
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(9.0),
                                        color: const Color(0xffffffff),
                                        boxShadow: [
                                          BoxShadow(
                                            color: const Color(0x40000000),
                                            offset: Offset(0, 6),
                                            blurRadius: 15,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, start: 24.5),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              PageLink(
                                            links: [
                                              PageLinkInfo(
                                                ease: Curves.easeOut,
                                                duration: 0.3,
                                                pageBuilder: () =>
                                                    logo_WebHome1(),
                                              ),
                                            ],
                                            child: Stack(
                                              children: <Widget>[
                                                Pinned.fromPins(
                                                  Pin(start: 0.0, end: 0.0),
                                                  Pin(start: 0.0, end: 0.0),
                                                  child:
                                                      // Adobe XD layer: 'Bg' (shape)
                                                      Container(
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                      color: const Color(
                                                          0xff293241),
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: const Color(
                                                              0x29000000),
                                                          offset: Offset(0, 3),
                                                          blurRadius: 6,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Pinned.fromPins(
                                                  Pin(size: 23.6, middle: 0.5),
                                                  Pin(size: 23.6, middle: 0.5),
                                                  child:
                                                      // Adobe XD layer: 'Edit' (group)
                                                      Stack(
                                                    children: <Widget>[
                                                      Pinned.fromPins(
                                                        Pin(
                                                            start: 0.0,
                                                            end: 0.0),
                                                        Pin(
                                                            start: 0.0,
                                                            end: 0.0),
                                                        child:
                                                            // Adobe XD layer: 'Artboard' (group)
                                                            Stack(
                                                          children: <Widget>[
                                                            Pinned.fromPins(
                                                              Pin(
                                                                  start: 0.0,
                                                                  end: 0.0),
                                                              Pin(
                                                                  start: 0.0,
                                                                  end: 0.0),
                                                              child:
                                                                  // Adobe XD layer: 'edit' (group)
                                                                  Stack(
                                                                children: <
                                                                    Widget>[
                                                                  Pinned
                                                                      .fromPins(
                                                                    Pin(
                                                                        start:
                                                                            0.0,
                                                                        end:
                                                                            2.4),
                                                                    Pin(
                                                                        start:
                                                                            2.4,
                                                                        end:
                                                                            0.0),
                                                                    child:
                                                                        // Adobe XD layer: 'Shape' (shape)
                                                                        SvgPicture
                                                                            .string(
                                                                      _svg_ydphff,
                                                                      allowDrawingOutsideViewBox:
                                                                          true,
                                                                      fit: BoxFit
                                                                          .fill,
                                                                    ),
                                                                  ),
                                                                  Pinned
                                                                      .fromPins(
                                                                    Pin(
                                                                        size:
                                                                            16.5,
                                                                        end:
                                                                            0.0),
                                                                    Pin(
                                                                        size:
                                                                            16.5,
                                                                        start:
                                                                            0.0),
                                                                    child:
                                                                        // Adobe XD layer: 'Shape' (shape)
                                                                        SvgPicture
                                                                            .string(
                                                                      _svg_vqr7e,
                                                                      allowDrawingOutsideViewBox:
                                                                          true,
                                                                      fit: BoxFit
                                                                          .fill,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, start: 99.5),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, middle: 0.3072),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, middle: 0.4869),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, middle: 0.6729),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, end: 110.0),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, end: -35.0),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, end: -180.0),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, end: -325.0),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, middle: 0.2174),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'V' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff93bc54),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 28.2, middle: 0.5),
                                                Pin(size: 18.8, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'V' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_yo0pcy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, middle: 0.397),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, middle: 0.5767),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'V' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff93bc54),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 28.2, middle: 0.5),
                                                Pin(size: 18.8, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'V' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_yo0pcy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, middle: 0.7627),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, end: 40.0),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, end: -105.0),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'V' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff93bc54),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 28.2, middle: 0.5),
                                                Pin(size: 18.8, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'V' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_yo0pcy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, end: -250.0),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 69.0, end: 72.0),
                                    Pin(size: 50.0, end: -395.0),
                                    child:
                                        // Adobe XD layer: 'UserInformation' (group)
                                        Stack(
                                      children: <Widget>[
                                        Pinned.fromPins(
                                          Pin(size: 1.0, start: 126.0),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_b0acqd,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.2353),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dxjhvm,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.3559),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_dbzg5,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.4911),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_fyv96,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 1.0, middle: 0.5943),
                                          Pin(start: 3.5, end: 5.5),
                                          child:
                                              // Adobe XD layer: 'Sepair' (shape)
                                              SvgPicture.string(
                                            _svg_s51tj,
                                            allowDrawingOutsideViewBox: true,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 50.0, start: 0.0),
                                          Pin(start: 0.0, end: 0.0),
                                          child:
                                              // Adobe XD layer: 'UserImage' (shape)
                                              Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.elliptical(
                                                      9999.0, 9999.0)),
                                              image: DecorationImage(
                                                image: const AssetImage(''),
                                                fit: BoxFit.cover,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color:
                                                      const Color(0x29000000),
                                                  offset: Offset(0, 3),
                                                  blurRadius: 6,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 109.0, start: 177.2),
                                          Pin(size: 25.0, middle: 0.5),
                                          child:
                                              // Adobe XD layer: 'NickName' (text)
                                              Text(
                                            '_.saurino._',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                              fontSize: 21,
                                              color: const Color(0xff293241),
                                              fontStyle: FontStyle.italic,
                                              fontWeight: FontWeight.w300,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 126.0, middle: 0.6857),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Code' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(start: 15.8, end: 15.2),
                                                Pin(size: 25.0, middle: 0.5588),
                                                child:
                                                    // Adobe XD layer: 'Code' (text)
                                                    Text(
                                                  'C-916025',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, end: 0.0),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'Edit' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 23.6, middle: 0.5),
                                                Pin(size: 23.6, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Edit' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child:
                                                          // Adobe XD layer: 'Artboard' (group)
                                                          Stack(
                                                        children: <Widget>[
                                                          Pinned.fromPins(
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            Pin(
                                                                start: 0.0,
                                                                end: 0.0),
                                                            child:
                                                                // Adobe XD layer: 'edit' (group)
                                                                Stack(
                                                              children: <
                                                                  Widget>[
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      start:
                                                                          0.0,
                                                                      end: 2.4),
                                                                  Pin(
                                                                      start:
                                                                          2.4,
                                                                      end: 0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_ydphff,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                                Pinned.fromPins(
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      end: 0.0),
                                                                  Pin(
                                                                      size:
                                                                          16.5,
                                                                      start:
                                                                          0.0),
                                                                  child:
                                                                      // Adobe XD layer: 'Shape' (shape)
                                                                      SvgPicture
                                                                          .string(
                                                                    _svg_vqr7e,
                                                                    allowDrawingOutsideViewBox:
                                                                        true,
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.2776),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3068),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7411),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 112.0, middle: 0.4153),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'SeeMail' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child:
                                                    // Adobe XD layer: 'Bg' (shape)
                                                    Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xff293241),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 38.0, middle: 0.3126),
                                                Pin(size: 25.0, middle: 0.5),
                                                child: Text(
                                                  'See',
                                                  style: TextStyle(
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 21,
                                                    color:
                                                        const Color(0xffffffff),
                                                    fontStyle: FontStyle.italic,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 21.0, middle: 0.7458),
                                                Pin(size: 13.5, middle: 0.5),
                                                child:
                                                    // Adobe XD layer: 'Eye' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_miy,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(
                                                          size: 7.8,
                                                          middle: 0.5),
                                                      Pin(start: 2.9, end: 2.9),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.elliptical(
                                                                      9999.0,
                                                                      9999.0)),
                                                          border: Border.all(
                                                              width: 1.5,
                                                              color: const Color(
                                                                  0xffffffff)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Pinned.fromPins(
                                          Pin(size: 42.0, middle: 0.5437),
                                          Pin(start: 3.0, end: 5.0),
                                          child:
                                              // Adobe XD layer: 'X' (group)
                                              Stack(
                                            children: <Widget>[
                                              Pinned.fromPins(
                                                Pin(start: 0.0, end: 0.0),
                                                Pin(start: 0.0, end: 0.0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                    color:
                                                        const Color(0xfffc5858),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: const Color(
                                                            0x29000000),
                                                        offset: Offset(0, 3),
                                                        blurRadius: 6,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Pinned.fromPins(
                                                Pin(size: 24.0, middle: 0.5),
                                                Pin(size: 24.0, middle: 0.5278),
                                                child:
                                                    // Adobe XD layer: 'X' (group)
                                                    Stack(
                                                  children: <Widget>[
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_l67b4l,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    Pinned.fromPins(
                                                      Pin(start: 0.0, end: 0.0),
                                                      Pin(start: 0.0, end: 0.0),
                                                      child: SvgPicture.string(
                                                        _svg_di6jx,
                                                        allowDrawingOutsideViewBox:
                                                            true,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, start: 153.0),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_c5ho7r,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, end: 105.5),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_hsb2zt,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, middle: 0.5275),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_bg7wb7,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, end: -185.5),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_uhhje7,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, middle: 0.3561),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_oi34bv,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, end: -40.5),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_lnpd21,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, middle: 0.6989),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_p7cw8f,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, end: -333.5),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_ciu1gv,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, middle: 0.2716),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_v8d5p,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, end: 25.5),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_z031r,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, middle: 0.6144),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_ki529,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, end: -258.5),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_f4qucv,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, middle: 0.443),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_tpe3w5,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, end: -116.5),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_vokphv,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  Pinned.fromPins(
                                    Pin(start: 38.0, end: 38.0),
                                    Pin(size: 1.0, middle: 0.7858),
                                    child:
                                        // Adobe XD layer: 'Line' (shape)
                                        SvgPicture.string(
                                      _svg_vt14d9,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 11.0, end: 0.0),
                  Pin(size: 202.0, start: 66.0),
                  child:
                      // Adobe XD layer: 'ScrollBar' (shape)
                      Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      color: const Color(0xffb7b7b7),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_id32xa =
    '<svg viewBox="21.4 21.4 10.9 10.9" ><path transform="translate(21.38, 21.38)" d="M 0 0 L 10.89804172515869 10.89804172515869" fill="none" stroke="#293241" stroke-width="3" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_ls6kho =
    '<svg viewBox="0.0 0.0 12.3 12.3" ><path transform="translate(-2.0, -2.0)" d="M 4.461095809936523 2 C 3.101869821548462 2 2 3.101869821548462 2 4.461095809936523 L 2 6.306917667388916 L 3.230548143386841 6.306917667388916 L 3.230548143386841 4.461095809936523 C 3.230548143386841 3.781482696533203 3.781482696533203 3.230548143386841 4.461095809936523 3.230548143386841 L 11.84438419342041 3.230548143386841 C 12.52401542663574 3.230548143386841 13.07493114471436 3.781482696533203 13.07493114471436 4.461095809936523 L 13.07493114471436 11.84438419342041 C 13.07493114471436 12.52401542663574 12.52401542663574 13.07493114471436 11.84438419342041 13.07493114471436 L 4.461095809936523 13.07493114471436 C 3.781482696533203 13.07493114471436 3.230548143386841 12.52401542663574 3.230548143386841 11.84438419342041 L 3.230548143386841 9.998561859130859 L 2 9.998561859130859 L 2 11.84438419342041 C 2 13.20358467102051 3.101869821548462 14.30547904968262 4.461095809936523 14.30547904968262 L 11.84438419342041 14.30547904968262 C 13.20358467102051 14.30547904968262 14.30547904968262 13.20358467102051 14.30547904968262 11.84438419342041 L 14.30547904968262 4.461095809936523 C 14.30547904968262 3.101869821548462 13.20358467102051 2 11.84438419342041 2 L 4.461095809936523 2 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_r94of5 =
    '<svg viewBox="0.0 2.9 8.6 6.5" ><path transform="translate(-2.0, -3.83)" d="M 2.61527419090271 9.367742538452148 C 2.275470495223999 9.367742538452148 2 9.643200874328613 2 9.983016967773438 C 2 10.32283401489258 2.275470495223999 10.59829139709473 2.61527419090271 10.59829139709473 L 8.511137008666992 10.59829139709473 L 6.951047420501709 12.15831851959229 C 6.7107834815979 12.39864444732666 6.7107834815979 12.78817462921143 6.951047420501709 13.02850151062012 C 7.191312789916992 13.26876449584961 7.58090353012085 13.26876449584961 7.821168422698975 13.02850151062012 L 10.40267372131348 10.44699573516846 C 10.53206539154053 10.33415412902832 10.61383628845215 10.16815376281738 10.61383628845215 9.983016967773438 C 10.61383628845215 9.797881126403809 10.53206539154053 9.631879806518555 10.40267372131348 9.519039154052734 L 7.821168422698975 6.937564849853516 C 7.58090353012085 6.697282314300537 7.191312789916992 6.697282314300537 6.951047420501709 6.937564849853516 C 6.7107834815979 7.177841663360596 6.7107834815979 7.5674147605896 6.951047420501709 7.80769157409668 L 8.511137008666992 9.367742538452148 L 2.61527419090271 9.367742538452148 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_o73wkp =
    '<svg viewBox="4.0 4.0 12.0 10.0" ><path transform="translate(2.0, 1.0)" d="M 6 9 C 6.931910037994385 9 7.714960098266602 9.63737964630127 7.936989784240723 10.5 L 13.5 10.5 C 13.77610015869141 10.5 14 10.72389984130859 14 11 C 14 11.24549961090088 13.82310009002686 11.44960021972656 13.58990001678467 11.49190044403076 L 13.5 11.5 L 7.936729907989502 11.50100040435791 C 7.71435022354126 12.36310005187988 6.931550025939941 13 6 13 C 5.068449974060059 13 4.28564977645874 12.36310005187988 4.063270092010498 11.50100040435791 L 2.5 11.5 C 2.223860025405884 11.5 2 11.27610015869141 2 11 C 2 10.75450038909912 2.1768798828125 10.55039978027344 2.410120010375977 10.50809955596924 L 2.5 10.5 L 4.063010215759277 10.5 C 4.285039901733398 9.63737964630127 5.068089962005615 9 6 9 Z M 6 10 C 5.447720050811768 10 5 10.44769954681396 5 11 C 5 11.55230045318604 5.447720050811768 12 6 12 C 6.552279949188232 12 7 11.55230045318604 7 11 C 7 10.44769954681396 6.552279949188232 10 6 10 Z M 10 3 C 10.93190002441406 3 11.71500015258789 3.637379884719849 11.9370002746582 4.499979972839355 L 13.5 4.5 C 13.77610015869141 4.5 14 4.723859786987305 14 5 C 14 5.245460033416748 13.82310009002686 5.449610233306885 13.58990001678467 5.491940021514893 L 13.5 5.5 L 11.93669986724854 5.501019954681396 C 11.71440029144287 6.363120079040527 10.93159961700439 7 10 7 C 9.068449974060059 7 8.285650253295898 6.363120079040527 8.06326961517334 5.501019954681396 L 2.5 5.5 C 2.223860025405884 5.5 2 5.276140213012695 2 5 C 2 4.754539966583252 2.1768798828125 4.550389766693115 2.410120010375977 4.508059978485107 L 2.5 4.5 L 8.063010215759277 4.499979972839355 C 8.285039901733398 3.637379884719849 9.068090438842773 3 10 3 Z M 10 4 C 9.447710037231445 4 9 4.447720050811768 9 5 C 9 5.552279949188232 9.447710037231445 6 10 6 C 10.55230045318604 6 11 5.552279949188232 11 5 C 11 4.447720050811768 10.55230045318604 4 10 4 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_mff9v5 =
    '<svg viewBox="67.5 186.5 136.0 1.0" ><path transform="translate(67.5, 186.5)" d="M 0 0 L 136 0" fill="none" stroke="#3d5a80" stroke-width="0.5" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_f5ver5 =
    '<svg viewBox="67.5 226.5 136.0 1.0" ><path transform="translate(67.5, 226.5)" d="M 0 0 L 136 0" fill="none" stroke="#3d5a80" stroke-width="0.5" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_i2lg39 =
    '<svg viewBox="478.0 164.0 1.0 41.0" ><path transform="translate(478.0, 164.0)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_wwi3s =
    '<svg viewBox="682.4 164.0 1.0 41.0" ><path transform="translate(682.43, 164.0)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_h40j9 =
    '<svg viewBox="851.6 164.0 1.0 41.0" ><path transform="translate(851.62, 164.0)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_eg3vye =
    '<svg viewBox="1041.6 164.0 1.0 41.0" ><path transform="translate(1041.56, 164.0)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_vtr839 =
    '<svg viewBox="1186.2 164.0 1.0 41.0" ><path transform="translate(1186.22, 164.0)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_b0acqd =
    '<svg viewBox="478.0 236.5 1.0 41.0" ><path transform="translate(478.0, 236.5)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_dxjhvm =
    '<svg viewBox="682.4 236.5 1.0 41.0" ><path transform="translate(682.43, 236.5)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_dbzg5 =
    '<svg viewBox="851.6 236.5 1.0 41.0" ><path transform="translate(851.62, 236.5)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_fyv96 =
    '<svg viewBox="1041.6 236.5 1.0 41.0" ><path transform="translate(1041.56, 236.5)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_s51tj =
    '<svg viewBox="1186.4 236.5 1.0 41.0" ><path transform="translate(1186.44, 236.5)" d="M 0 0 L 0 41" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_ydphff =
    '<svg viewBox="0.0 2.4 21.3 21.3" ><path transform="translate(0.0, 0.36)" d="M 21.2590389251709 14.59007740020752 L 21.2590389251709 20.89692497253418 C 21.2590389251709 22.20148468017578 20.20147895812988 23.25904083251953 18.89692497253418 23.25904083251953 L 2.362115621566772 23.25904083251953 C 1.057554960250854 23.25904083251953 0 22.20148468017578 0 20.89692497253418 L 0 4.362114906311035 C 0 3.057554960250854 1.057555437088013 1.999999523162842 2.362115859985352 1.999999761581421 L 8.668963432312012 1.999999761581421" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_vqr7e =
    '<svg viewBox="7.1 0.0 16.5 16.5" ><path transform="translate(1.09, 0.0)" d="M 17.81057929992676 0 L 22.53481101989746 4.724231243133545 L 10.7242317199707 16.5348072052002 L 5.999999523162842 16.5348072052002 L 5.999999523162842 11.81057739257812 L 17.81057929992676 0 Z" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_miy =
    '<svg viewBox="0.0 0.0 21.0 13.5" ><path transform="translate(-16.0, -55.99)" d="M 26.50000190734863 55.99220275878906 C 19 55.99220275878906 16 62.74292755126953 16 62.74292755126953 C 16 62.74292755126953 19 69.49220275878906 26.50000190734863 69.49220275878906 C 34 69.49220275878906 37 62.74292755126953 37 62.74292755126953 C 37 62.74292755126953 34 55.99220275878906 26.50000190734863 55.99220275878906 Z" fill="none" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_l67b4l =
    '<svg viewBox="0.0 0.0 24.0 24.0" ><path transform="translate(-0.02, 0.0)" d="M 24 0 L 0 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_di6jx =
    '<svg viewBox="0.0 0.0 24.0 24.0" ><path transform="translate(-0.02, 0.0)" d="M 24 24 L 0 0" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_yo0pcy =
    '<svg viewBox="48.0 72.0 28.2 18.8" ><path transform="translate(0.0, 0.0)" d="M 76.24755859375 72.00498962402344 L 57.41585159301758 90.83585357666016 L 47.99999618530273 81.42084503173828" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>';
const String _svg_c5ho7r =
    '<svg viewBox="60.5 157.0 1470.0 1.0" ><path transform="translate(60.5, 157.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_hsb2zt =
    '<svg viewBox="60.5 727.0 1470.0 1.0" ><path transform="translate(60.5, 727.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_bg7wb7 =
    '<svg viewBox="60.5 441.0 1470.0 1.0" ><path transform="translate(60.5, 441.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_uhhje7 =
    '<svg viewBox="60.5 1018.0 1470.0 1.0" ><path transform="translate(60.5, 1018.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_oi34bv =
    '<svg viewBox="60.5 299.0 1470.0 1.0" ><path transform="translate(60.5, 299.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_lnpd21 =
    '<svg viewBox="60.5 873.0 1470.0 1.0" ><path transform="translate(60.5, 873.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_p7cw8f =
    '<svg viewBox="60.5 583.0 1470.0 1.0" ><path transform="translate(60.5, 583.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_ciu1gv =
    '<svg viewBox="60.5 1166.0 1470.0 1.0" ><path transform="translate(60.5, 1166.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_v8d5p =
    '<svg viewBox="60.5 229.0 1470.0 1.0" ><path transform="translate(60.5, 229.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_z031r =
    '<svg viewBox="60.5 807.0 1470.0 1.0" ><path transform="translate(60.5, 807.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_ki529 =
    '<svg viewBox="60.5 513.0 1470.0 1.0" ><path transform="translate(60.5, 513.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_f4qucv =
    '<svg viewBox="60.5 1091.0 1470.0 1.0" ><path transform="translate(60.5, 1091.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_tpe3w5 =
    '<svg viewBox="60.5 371.0 1470.0 1.0" ><path transform="translate(60.5, 371.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_vokphv =
    '<svg viewBox="60.5 949.0 1470.0 1.0" ><path transform="translate(60.5, 949.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_vt14d9 =
    '<svg viewBox="60.5 655.0 1470.0 1.0" ><path transform="translate(60.5, 655.0)" d="M 0 0 L 1470 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _svg_lsenq1 =
    '<svg viewBox="293.5 212.5 1526.0 1.0" ><path transform="translate(293.5, 212.5)" d="M 0 0 L 1526 0" fill="none" stroke="#293241" stroke-width="1" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
